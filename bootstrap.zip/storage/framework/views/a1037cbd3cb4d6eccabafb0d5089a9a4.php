<?php echo $__env->make('header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main id="main" >
    <section class="single-post-content" >
      <div class="container" >
    
            <!-- ======= Comments Form ======= --> 
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                </div>
             <?php endif; ?>
             <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <a href="<?php echo e(route('allCourses')); ?>"  class="btn btn-outline-success float-end">Back to All Courses</a>
            <div class="row justify-content-center mt-5">
              <div class="col-lg-6">
                <h5 class="comment-title">We are verifying if you are Enrolled to some Courses.</h5>
                <h6>Please use the same email as one used to register to this course</h6><br/>
                 <form id="userVerify" method="POST" action="<?php echo e(route('verifyPaidCourses')); ?>">
                            <?php echo csrf_field(); ?>
                        <div class="form-group"> 
                            <label>Given Email</label>
                            <input class="form-control" type="text" id="EnrolledUserEmail" name="userEmail" value="" required>
                        </div><br/>
                        <div class="form-group"> 
                            <button  class="btn btn-primary" type="submit"  id="btn-submit">Enroll</button>
                        </div>
                    </form>
                </div>
                </div>
                </div>
                </div>
              </div>
            </div>
               
            <!-- End Comments Form -->
          </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->

   <!-- ======= Footer ======= -->
   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Vendor JS Files -->
<script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="../../assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="../../assets/vendor/aos/aos.js"></script>
<script src="../../assets/vendor/php-email-form/validate.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<!-- Template Main JS File -->
<script src="../../assets/js/main.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\intogore\resources\views/verifyEnroll.blade.php ENDPATH**/ ?>