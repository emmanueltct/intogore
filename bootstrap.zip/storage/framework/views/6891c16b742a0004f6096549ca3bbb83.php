<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">
    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <a href="<?php echo e(route('courseForm')); ?>"class="btn btn-outline-primary btn-sm float-start" ><i class="bi bi-plus"></i> Add New</a>
          <a href="<?php echo e(route('subCourseForm')); ?>"class="btn btn-outline-primary btn-sm float-end" ><i class="bi bi-plus"></i> Add New chapter</a><br/><br/>
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops!!</h1>
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>

          <?php if(count($course)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Courses</th>
                    <th scope="col">Description</th>
                    <th scope="col">Subscription</th>
                    <th scope="col">Price</th>
                    <th scope="col" colspan="2">Enrolled Users</th>
                    <th scope="col" colspan="2">Chapters</th>
                    <th scope="col" colspan="2">Management Course</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                  
                    <?php
                        $Number_subcourse = App\Models\course::find($c->id)->subcourses()->count('id');
                        $number=$Number_subcourse;
                        $Number_subcourse+=1;
                        $Pendingsubcourse=App\Models\course::find($c->id)->subcourses()->where('coursePublishment','Pending')->count('id');
                        $enrolled = App\Models\course::find($c->id)->course_enrollments()->count('id');
                        $unproved_enrolled_user=App\Models\course::find($c->id)->course_enrollments()->where('coursePayment','Not Paid')->count('id');
                        //foreach ($comments as $comment) {}
                      
                      ?>
      
                    <th><?php echo e($a); ?></th> 
                    <td><?php echo e($c->courseTitle); ?></td>
                    <td><?php echo e($c->courseDescription); ?></td>
                    <td><?php echo e($c->CourseEnroll); ?></td>
                    <td><?php echo e($c->CoursePrice); ?></td>
                    <td>Total registered users(<?php echo e($enrolled); ?>)</td>
                    <td>User Pending for Approval(<?php echo e($unproved_enrolled_user); ?>)</td>
                    <td>All Chapters(<?php echo e($number); ?>)</td>
                    <td>Pending for Approval(<?php echo e($Pendingsubcourse); ?>)</td>
              
                    <td>
                       <a class="btn btn-primary btn-sm" href="<?php echo e(route('editCourseForm',$c->id)); ?>" title="Edit Course" ><i class="bi bi-pencil"></i></a><br/><br/>
                       <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('checkEnrolledUser',['Course'=>$c->id])); ?>" title="Enrolled Users"><i class="bi bi-people"></i></a>
                    </td>
                    <td>
                      <form method="POST" action="<?php echo e(route('deleteCourse',$c->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Course"><i class="bi bi-trash"></i></button><br/><br/>
                      </form>
                      <a class="btn btn-outline-success btn-sm" href="<?php echo e(route('allSubCourse',['Chapter'=>$c->id])); ?>" title="Course Chapters"><i class="bi bi-list"></i></a> 
                      
                    </td>
                  </tr> 
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seem s like no person enrolled to any course</span> <br>
              <i style="color:red">Please keep refreshing for any update</i> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-View-All-Course.blade.php ENDPATH**/ ?>