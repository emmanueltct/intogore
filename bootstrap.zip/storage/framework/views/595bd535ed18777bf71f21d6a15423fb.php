<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">
    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <?php if($main): ?>
            <a href="<?php echo e(route('allSubCourse',['Chapter'=>$main])); ?>" class="btn btn-primary btn-sm">Back chapters</a>
            <?php else: ?>
          <a href="<?php echo e(route('AdmincourseList')); ?>" class="btn btn-primary btn-sm">Back To Our Course Lists</a>
          <?php endif; ?>
          <br/><br/>
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <h1>Oops!!</h1>
                   <h3> <?php echo e(implode(' ', $errors->all(':message'))); ?></h3>
                   <br/>
                  </div>
             <?php endif; ?>

          <?php if(count($comments)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Course Title</th>
                    <th scope="col">Names</th>
                    <th scope="col">Email</th>
                    <th scope="col">Comments</th>
                    <th scope="col">status</th>
                    <th scope="col">Date</th>
                    <th colspan="3">Admin Take Actions on Comments</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                    <th scope="row"><?php echo e($a); ?></th>
                    <td><?php echo e($user->mainTitle); ?></td>
                    <td><?php echo e($user->userName); ?></td>
                    <td><?php echo e($user->userEmail); ?></td>
                    <td><?php echo e($user->courseComments); ?></td>
                    <td><?php echo e($user->Approval); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td>
                        <span >
                            <form method="post" action="<?php echo e(route('confirmComment')); ?>" style="margin-bottom:4px"   >
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="course_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" class="btn btn-primary btn-sm " <?php if($user['Approval']=="Approved"){echo"disabled";} ?> >Confirm</button>
                            </form>
                        </span>
                    </td>
                    <td>
                    <span>  
                        <form method="post" id="RemovePayment" action="<?php echo e(route('removeComment')); ?>">
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="course_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </span>
                    </td>
                </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <?php if(!$errors->any()): ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>Selected course doesn't have any comment</span> <br>
              <i style="color:#842404">Please keep refreshing for any update to this course</i> </h3><br/>
            </div> 
            <?php endif; ?>
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/admin_comment.blade.php ENDPATH**/ ?>