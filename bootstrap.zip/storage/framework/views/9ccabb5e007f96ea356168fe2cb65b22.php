<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-12 text-center mb-5">
          <a href="<?php echo e(route('subCourseForm')); ?>"class="btn btn-outline-primary btn-sm float-end" ><i class="bi bi-plus"></i> Add New chapter</a><br/><br/>
            <h3 class="page-title" style="font-size:24px">Describe your Post here</h3>
          </div>
        <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
         <?php endif; ?>
        </div>
          <form method="post"  action="<?php echo e(route('postCourseForm')); ?>"  class="php-email-form" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="courseTitle" class="form-control" id="postTitle" placeholder="Write your category name" required>
            </div>
            <div class="form-group">
              <label>Put attractive content for your visitors no more than 800 words</label> 
              <textarea  class="form-control" name="mainCourseIntro" rows="3" placeholder="Attractive summary for course [max characters:800]" required></textarea>
            </div>
            <div class="my-3">
              <div class="loading">Loading</div>
              <div class="error-message"></div>
              <div class="sent-message">Your message has been sent. Thank you!</div>
            </div>
           
            <div class="text-center"><input type="submit" value="Send Post"></div>
          </form>
        </div><!-- End Contact Form -->
      </div>
     
    </section>

  </main><!-- End #main -->

  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/add-course.blade.php ENDPATH**/ ?>