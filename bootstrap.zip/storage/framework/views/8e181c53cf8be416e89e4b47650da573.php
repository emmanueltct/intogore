<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
    .table td,th {
      text-align: center;
      }
     
  </style>
  <!-- =======================================================
  * Template Name: ZenBlog
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->

  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
            
          <div class="col-md-12">
          <a href="<?php echo e(route('categoryForm')); ?>"class="btn btn-outline-primary btn-sm float-end" ><i class="bi bi-plus"></i> Add New</a> <br/><br/> 
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops!!</h1>
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>

          <?php if(count($category)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">category titlie</th>
                    <th scope="col">Created_at</th>
                    <th scope="col" colspan="2">Management Data</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                    <th><?php echo e($a); ?></th> 
                    <td><?php echo e($cat->category); ?></td>
                    <td><?php echo e($cat->created_at); ?></td>
                    <td>
                       <a class="btn btn-primary btn-sm" href="<?php echo e(route('editCategoryForm',$cat->id)); ?>" title="Viw more information on Post" ><i class="bi bi-pencil"></i></a><br/><br/>
                    </td>
                    <td>
                        <form method="post" action="<?php echo e(route('deleteCategory',$cat->id)); ?>">
                            <?php echo csrf_field(); ?> 
                            <input type="hidden" name="post_id" value="<?php echo e($cat->id); ?>">
                            <button type="submit" class="btn btn-success btn-sm" ><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                  </tr> 
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seems like no Post available</span> <br>
              <i style="color:red">Please keep refreshing for any update</i> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-Post-Category.blade.php ENDPATH**/ ?>