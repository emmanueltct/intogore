<?php echo $__env->make('titles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <h1>Oops!!</h1>
                   <h3> <?php echo e(implode(' ', $errors->all(':message'))); ?></h3>
                   <br/>
                   <?php if(!$errors->user_update): ?>
                   <a href="<?php echo e(route('AdmincourseList')); ?>" class="btn btn-primary btn-sm">Back To Our Course Lists</a>
                  <?php endif; ?>
                  </div>
             <?php endif; ?>

          <?php if(count($subscribed_user)>0): ?>
          <a href="<?php echo e(route('AdmincourseList')); ?>" class="btn btn-primary btn-sm">Back To Our Course Lists</a>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Names</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Payment</th>
                    <th scope="col">Approved</th>
                    <th scope="col">Course Title</th>
                    <th scope="col">Course status</th>
                    <th scope="col">Course Price</th>
                    <th scope="col">User Subscription date</th>
                    <th colspan="3">Admin Take Actions on Payment</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $subscribed_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                    <th scope="row"><?php echo e($a); ?></th>
                    <td><?php echo e($user->names); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->payment); ?></td>
                    <td><?php echo e($user->code); ?></td>
                    <td><?php echo e($user->title); ?></td>
                    <td><?php echo e($user->enroll); ?></td>
                    <td><?php echo e($user->price); ?></td>
                    <td><?php echo e($user->date); ?></td>
                    <td>
                        <span >
                            <form method="post" action="<?php echo e(route('confirmEnrolledUser')); ?>" style="margin-bottom:4px"   >
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="course_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" class="btn btn-primary btn-sm " <?php if($user['payment']=="Paid"){echo"disabled";} ?> >Confirm</button>
                            </form>
                        </span>
                    </td>
                    <td>
                        <span>  
                        <form method="post" id="RemovePayment" action="<?php echo e(route('removeEnrolledUser')); ?>">
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="course_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" class="btn btn-warning btn-sm " <?php if($user['payment']=="Not Paid"){echo"disabled";} ?> >Remove</button>
                          </form>
                        </span>
                    </td>
                    <td>
                    <span>  
                        <form method="post" id="RemovePayment" action="<?php echo e(route('deleteEnrolledUser')); ?>">
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="course_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </span>
                    </td>
                </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <?php if(!$errors->any()): ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seem s like no person enrolled to any course</span> <br>
              <i style="color:#842404">Please keep refreshing for any update or check if the course is Free charges</i> </h3><br/>
              <a href="<?php echo e(route('AdmincourseList')); ?>" class="btn btn-primary btn-sm">Back To Our Course Lists</a>
            </div> 
            <?php endif; ?>
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/enrolled-Users.blade.php ENDPATH**/ ?>