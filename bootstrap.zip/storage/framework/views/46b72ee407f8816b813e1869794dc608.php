<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ZenBlog Bootstrap Template - Search Results</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500&family=Inter:wght@400;500&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

<?php echo $__env->make('header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-8" style="padding-right:2%">
          <?php if(count($post)): ?>
            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-md-flex post-entry-2 small-img">
              <a href="single-post.html" class="me-4 thumbnail">
                <img src=<?php echo e(URL::asset("images/$p->postthumbnail")); ?> alt="" class="img-fluid">
              </a>
              <div>
                <div class="post-meta"><span class="date"><?php echo e($p->cat); ?></span> <span class="mx-1">&bullet;</span> <span><?php echo e($post[0]->createdat); ?></span></div>
                <h3><a href="<?php echo e(route('readsinglepost',$p->PostEndLink)); ?>"><?php echo e($p->posttitle); ?></a></h3>
                <p><?php echo e(substr($p->postdescription,0,205)."......."); ?></p>
                <div class="d-flex align-items-center author">
                  <div class="photo"><img src="assets/img/person-2.jpg" alt="" class="img-fluid"></div>
                  <div class="name">
                    
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <!-- Paging -->
            <?php echo e($post->links('vendor.pagination.custom')); ?>

            <!--
            <div class="text-start py-4">
              <div class="custom-pagination">
               
                <a href="#" class="prev">Prevous</a>
                <a href="#" class="active">1</a>
                 <?php echo $post->links(); ?>

                 <a href="#">1</a>
                 <a href="#">2</a>
                 <a href="#">3</a>
                <a href="#" class="next">Next</a>
              </div>
            </div> -->
            <!-- End Paging -->
            <?php else: ?>
            <div class="single-post alert alert-danger" >
              <h1 >Oops!!</h1>
              <h3>The post you are trying to read is not found! <br> <i style="color:red">Use our navigation links  for different posts on this platform</i> </h3>
              <br><br>
            </div>
            <?php endif; ?>
          </div>

          <div class="col-md-4" style="padding-left:4%" >
            <!-- ======= Sidebar ======= -->
            <div class="aside-block">

              <ul class="nav nav-pills custom-tab-nav mb-4" id="pills-tab" role="tablist">
              <?php if(count($counter)>0): ?>
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-popular-tab" data-bs-toggle="pill" data-bs-target="#pills-popular" type="button" role="tab" aria-controls="pills-popular" aria-selected="true">Popular Posts</button>
                </li>
              <?php endif; ?>
              <?php if(count($latest)>0): ?>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-latest-tab" data-bs-toggle="pill" data-bs-target="#pills-latest" type="button" role="tab" aria-controls="pills-latest" aria-selected="false">Latest Posts</button>
                </li>
              <?php endif; ?>
              </ul>

              <div class="tab-content" id="pills-tabContent">

                <!-- Popular -->
                <div class="tab-pane fade show active" id="pills-popular" role="tabpanel" aria-labelledby="pills-popular-tab">
                  <?php if(count($counter)>0): ?>
                  <?php $__currentLoopData = $counter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?php echo e($count->cat); ?></span> <span class="mx-1">&bullet;</span> <span>Jul 5th '22</span></div>
                    <h2 class="mb-2"><a href="<?php echo e(route('readsinglepost',$count->PostEndLink)); ?>"><?php echo e($count->post_title); ?></a></h2>
                    <span class="author mb-3 d-block"><?php echo e($count->LikeCount); ?> Likes || <?php echo e($count->created_date); ?></span>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div> <!-- End Popular -->

                <!-- Latest -->
                <div class="tab-pane fade" id="pills-latest" role="tabpanel" aria-labelledby="pills-latest-tab">
                 <?php if(count($latest)>0): ?>
                  <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $late): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?php echo e($late->cat); ?></span> <span class="mx-1">&bullet;</span> <span><?php echo e($late->created_date); ?></span></div>
                    <h2 class="mb-2"><a href="<?php echo e(route('readsinglepost',$late->PostEndLink)); ?>"><?php echo e($late->post_title); ?></a></h2>
                    <span class="author mb-3 d-block"></span>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div> <!-- End Latest -->

              </div>
            </div>

              <!-- ======= Sidebar ======= -->
              <?php if(count($recommendVideo)>0): ?>
              <div class="aside-block">
              <h3 class="aside-title">Recommended Video</h3>
              <div class="video-post">
              
              <?php echo e($recommendVideo[0]->VideoTitle); ?>

                 <a href="<?php echo e($recommendVideo[0]->sourceLink); ?>" target="_blank" title="<?php echo e($recommendVideo[0]->VideoTitle); ?>" class="link-video">
                    <embed src="<?php echo e($recommendVideo[0]->sourceLink); ?>" alt="" class="img-fluid"> </embed>
                </a>
              </div>
            </div><!-- End Video -->
            <?php endif; ?>
            <div class="aside-block" >
              <h3 class="aside-title">View Posts by Categories</h3>
              <ul class="aside-links list-unstyled" style="color:black">
                <li><a href="<?php echo e(route('allPost','All')); ?>"><i class="bi bi-chevron-right"></i>All</a></li>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('allPost',$cat->categoryEndLink)); ?>"><i class="bi bi-chevron-right"></i><?php echo e($cat->category); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div><!-- End Categories -->
          </div>
          
        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\intogore\resources\views/all-post.blade.php ENDPATH**/ ?>