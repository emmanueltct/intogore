<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
    .table td,th {
      text-align: center;
      }
     
  </style>
 

  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops!!</h1>
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>
          
             <a href="<?php echo e(route('alltrendingForm')); ?>"class="btn btn-outline-primary btn-sm float-start" ><i class="bi bi-plus"></i> Add New</a>
              <br/><br/>
             <?php if(count($trending)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Title</th>
                    <th scope="col">description</th>
                    <th scope="col">Shared Link</th>
                    <th scope="col">Status</th>
                    <td>Created at</td>
                    <th scope="col">Admin actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                    
                    <th><?php echo e($a); ?></th> 
                    <td><?php echo e($p->trendingTitle); ?></td>
                    <td><?php echo e($p->Comments); ?></td>
                    <td><?php echo e($p->sourceLink); ?></td>
                    <td><?php echo e($p->status); ?></td>
                    <td><?php echo e($p->created_at); ?></td>
                    <td>
                    <div style="display:flex;flex-direction:row; justify-content: space-around;gap:5px" >
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('AdminEditPostTrending',$p->id)); ?>" title="Edit product information" >Edit</a>
                      
                      <form action="<?php echo e(route('AdminPublishPostTrending',$p->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="trending_id" value="<?php echo e($p->id); ?>">
                         <button type="submit" class="btn btn-success btn-sm" href="<?php echo e(route('allSubCourse',['Chapter'=>$p->id])); ?>" title="Publish Product">Publish</button> 
                       </form>

                       <form action="<?php echo e(route('AdminDestroyPostTrending',$p->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="trending_id" value="<?php echo e($p->id); ?>">
                         <button type="submit" class="btn btn-danger btn-sm" title="Delete Product">Delete</button> 
                       </form>
                      </div>
                    </td>
                  </tr> 
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seem s like no person enrolled to any course</span> <br>
              <i style="color:red">Please keep refreshing for any update</i> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-All-TrendingPost.blade.php ENDPATH**/ ?>