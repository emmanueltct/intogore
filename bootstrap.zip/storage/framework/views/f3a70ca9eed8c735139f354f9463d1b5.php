<?php echo $__env->make('titles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
    .table td,th {
      text-align: center;
      }
     
  </style>
  <!-- =======================================================
  * Template Name: ZenBlog
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->

  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <a href="<?php echo e(route('postform')); ?>"class="btn btn-outline-primary btn-sm float-start" ><i class="bi bi-plus"></i> Add New</a> <br/><br/> 
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops!!</h1>
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>

          <?php if(count($post)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Post titlie</th>
                    <th scope="col">Category</th>
                    <th scope="col">Status</th>
                    <th scope="col">Like</th>
                    <th scope="col">Comments</th>
                    <th scope="col" colspan="2">Management Post</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                  
                    <?php
                        $like = App\Models\Post::find($p->id)->trending_likes()->count('id');
                        $comments=App\Models\Post::find($p->id)->trending_comments()->count('id');
                               
                      ?>
      
                    <th><?php echo e($a); ?></th> 
                    <td><?php echo e($p->posttitle); ?></td>
                    <td><?php echo e($p->cat); ?></td>
                    <td><?php echo e($p->approval); ?></td>
                    <td>Total like(<?php echo e($like); ?>)</td>
                    <td>Total Comments(<?php echo e($comments); ?>)</td>
                    <td>
                       <a class="btn btn-primary btn-sm" href="<?php echo e(route('adminViewSinglePost',$p->id)); ?>" title="Viw more information on Post" ><i class="bi bi-eye"></i></a><br/><br/>
                    </td>
                    <td>
                      <a class="btn btn-outline-success btn-sm" href="<?php echo e(route('userPostComments',$p->id)); ?>" title="View Post comments"><i class="bi bi-chat"></i></a> 
                    </td>
                  </tr> 
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seems like no Post available</span> <br>
              <i style="color:red">Please keep refreshing for any update</i> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-All-Post.blade.php ENDPATH**/ ?>