<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <a href="<?php echo e(route('AdmincourseList')); ?>" class="btn btn-primary btn-sm">Back To Our Course Lists</a>
          <a href="<?php echo e(route('subCourseForm')); ?>"class="btn btn-outline-primary btn-sm float-end" ><i class="bi bi-plus"></i> Add New chapter</a><br/><br/>
          <br><br> 
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops</h1>
                 <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>

          <?php if(count($course)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Mian Course</th>
                    <th scope="col">sub Course</th>
                    <th scope="col">Status</th>
                    <th scope="col">Comments</th>
                    <th scope="col">Created Date</th>
                    <th colspan="2">Admin Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                    <th scope="row"><?php echo e($a); ?></th>
                    <td><?php echo e($c->main_course); ?></td>
                    <td><?php echo e($c->title); ?></td>
                    <td><?php echo e($c->publishes); ?></td>
                    <?php
                            $comment = App\Models\Subcourse::find($c->id)->course_comments()->count('id');
                          ?>
                            <?php
                            $UnApprovedcomment = App\Models\Subcourse::find($c->id)->course_comments()->where('Approval','Pending')->count('id');
                          ?>
                          <td> Total Comments(<?php echo e($comment); ?>)<br/>
                           Pending for Approval (<?php echo e($UnApprovedcomment); ?>)</td>
                          <td><?php echo e($c->created_at); ?></td>
                    <td>                   
                        <span>
                                <a href="<?php echo e(route('editSubCourse',$c->id)); ?>" class="btn btn-primary btn-sm "  title="Edit this Course chapter" ><i class="bi bi-pencil"></i></a>
                          
                        </span>
                    </td>
                    <td>
                        <span >
                          <a class="btn btn-success btn-sm " href="<?php echo e(route('showSingleSubCourse',$c->id)); ?>" title="detail info on Course"><i class="bi bi-info-circle"></i></a>
                        </span>
                        <span>  
                         <a href="<?php echo e(route('adminCourseComment',['Course'=>$c->id,'heading'=>$c->cat])); ?>" class="btn btn-outline-danger btn-sm" title="Course Comments"><i class="bi bi-chat"></i></a>
                        </span>
                    </td>
                </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seem s like you didn't add any chapter to this course</span> <br>
              <i style="color:red">Please your first chapter to this course</i> <a style="font-size:20px;" class="btn btn-outline-success btn-sm" href="<?php echo e(route('subCourseForm')); ?>">Click here to add chapter</a> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-view-subcourse.blade.php ENDPATH**/ ?>