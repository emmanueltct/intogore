<?php echo $__env->make('header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
        * {box-sizing: border-box}

        /* Style the tab */
        .tab {
        float: left;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
        width: 30%;
        height: 300px;
        }

        /* Style the buttons that are used to open the tab content */
        .tab button {
        display: block;
        background-color: inherit;
        color: black;
        padding: 22px 16px;
        width: 100%;
        border: none;
        outline: none;
        text-align: left;
        cursor: pointer;
        transition: 0.3s;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
        background-color: #ddd;
        }

        /* Create an active/current "tab button" class */
        .tab button.active {
        background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
        float: left;
        padding: 0px 12px;
        border: 1px solid #ccc;
        width: 70%;
        border-left: none;
     
        }

        .flip-box {
          background-color: transparent;
          width:100%;
          height: 150px;
          border: 1px solid #f1f1f1;
          perspective: 1000px;
        }

        .flip-box-inner {
          position: relative;
          width: 100%;
          height: 100%;
          text-align: center;
          transition: transform 0.8s;
          transform-style: preserve-3d;
        }

        .flip-box:hover .flip-box-inner {
          transform: rotateY(180deg);
        }

        .flip-box-front, .flip-box-back {
          position: absolute;
          width: 100%;
          height: 100%;
          overflow:hidden;
          -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
        }

        .flip-box-front {
          background-color: #bbb;
          color: black;
        }

        .flip-box-back {
          background-color: #555;
          color: white;
          padding:2%;
          transform: rotateY(180deg);
        }

        .course-link:hover{
          color:blue;
          font-size:14px;
          text-decoration:underline;
        }
        #price_area{
          animation: blinker 1.5s linear infinite;
            color: red;
            font-family: sans-serif;
        }
        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }
        
  </style>
  <main id="main">
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?> 
              
          <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>

        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <div class="tab">
               
                 <?php for($a=0;$a <count($course);$a++){
                        if($a==0){
                    ?> 
                        <button class="tablinks" id="defaultOpen" database-id="<?= $course[0]->id ?>" courseEnrollement="<?= $course[0]->CourseEnroll ?>" onclick="openCity(event, '<?= $course[0]->id ?>')"><?= $course[$a]->courseTitle; ?></button>
                       
                       <?php
                            }
                            else{
                        ?>
                            <button class="tablinks" database-id="<?= $course[$a]->id ?>" courseEnrollement="<?= $course[$a]->CourseEnroll ?>"  onclick="openCity(event, '<?= $course[$a]->id ?>')"><?= $course[$a]->courseTitle; ?></button>
                        <?php
                        }
                    }
                    ?>
              
            </div>
            
                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e($co->id); ?>" class="tabcontent" >
                     
                      <div>
                        <br/>
                        <strong><?php echo e($co->courseTitle); ?></strong>
                        <?php if($co->CourseEnroll=='Paid-Course'): ?>
                         <a href="<?php echo e(route('enrollmentCryptoCourses',$co->courseEndLink)); ?>" class=" btn btn-primary btn-sm float-end" >Enroll this course</a> 
                        <?php endif; ?>
                        <br/><br/>
                          <p><?php echo e($co->courseDescription); ?> </p>
                          
                          <?php if($co->CourseEnroll=='Paid-Course'): ?>
                            <h5><span id="price_area" style="width:30%">
                            <?php echo e("Course Price:".$co->CoursePrice); ?></span></h5>
                          
                          <?php endif; ?>
                          <br/>
                      </div>
                 
                      
                      <div id="subcourse-content">
                       <div class="row">
                        <?php
                        $comments = App\Models\course::find($co->id)->subcourses()->where('subcourses.coursePublishment','=','Released')->get();
                        foreach ($comments as $comment) {
                            //
                            ?>
                            <div class="col-lg-4">
                              <div class="content" style="background-color:red">
                              <div class="flip-box">
                                <div class="flip-box-inner">
                                  <div class="flip-box-front">
                                   <img src="./courses/images/<?=$comment['courseThumbnail']?>" class="img-fluid">
                                  </div>
                                   <div class="flip-box-back">
                                    <p><?=substr($comment['courseIntro'],0,160)?>....</p>
                                  </div>
                                </div>
                              </div>
                             </div>
                             <h4 style="font-size:16px; padding:10px 0 10px 0"><a class="course-link" href="<?php echo e(route('takeCourse',$comment->SubCourseEndLink)); ?>"><?= $comment['mainTitle']?></a></h4> 
                            </div>
                        <?php } ?>
                     </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
            </div>  
            </div>    
          </div>
      </div>
    </section>
</main><!-- End #main -->


<!-- ======= Footer ======= -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(URL::asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/vendor/php-email-form/validate.js')); ?>"></script>
<!-- Template Main JS File -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
  
}

// Get the element with id="defaultOpen" and click on it
  document.getElementById("defaultOpen").click();

   
    
   //  // or var clickedBtnID = this.id






</script>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\intogore\resources\views/All-course.blade.php ENDPATH**/ ?>