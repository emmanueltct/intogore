<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h3 class="page-title" style="font-size:24px">Describe your Post here</h3>
          </div>
        <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
         <?php endif; ?>
         <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <h1>Oops!!</h1>
                  <h3> <?php echo e(implode(' ', $errors->all(':message'))); ?></h3>
                   <br/>
              </div>
             <?php endif; ?>
        </div>
          <form method="post"  action="<?php echo e(route('save_editSubCourse',$subcourse->id)); ?>"  class="php-email-form" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="subcourse_id" value="<?php echo e($subcourse->id); ?>" required>
           <input type="hidden" name="current_image" value="<?php echo e($subcourse->courseThumbnail); ?>" required>
          <div class="form-group">
                <Select class="form-control" name="courseCategory" id="courseCategory" placeholder="">
                    <option>Select course category</option> 
                    <?php if(count($course)>0): ?>
                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php if($course->id==$subcourse->courseCategory)echo"selected" ?> ><?php echo e($course->courseTitle); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <input type="text" name="mainTitle" class="form-control" id="mainTitle" value="<?php echo e($subcourse->mainTitle); ?>" required>
            </div>
            <div class="form-group" style="color:red">
              <input type="file" class="form-control" name="courseThumbnail" id="courseThumbnail">
              <label>Change thumbnail here if you need too otherwise leave current</label>
            </div>
            <div class="form-group" style="max-width:300px">
              <img src="../../courses/images/<?php echo e($subcourse->courseThumbnail); ?>" alt="" class="img-fluid" >
              <label>Current thumbnail visible to web page</label>
            </div>
            <div class="form-group">
              <label>Put attractive content for your visitors no more than 500 words</label> 
              <textarea  class="form-control" name="courseIntro" rows="3" placeholder="Attractive summary [max characters:500]" required><?php echo e($subcourse->courseIntro); ?></textarea>
            </div>
            <div class="form-group">
              <textarea id="summernote" class="form-control" name="courseDescription" rows="5" placeholder="more description on course" required><?php echo e($subcourse->courseDescription); ?></textarea>
            </div>
            <div class="text-center"><input type="submit" value="Send Post"></div>
          </form>
        </div><!-- End Contact Form -->
      </div>
     
    </section>

  </main><!-- End #main -->

  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script type="text/javascript">
      $('#summernote').summernote({
        placeholder: 'Elaborate more on your post [ put all possible description ]',
        tabsize: 2,
        
        dialogsInBody: true,
        toolbar: [
          ['style', ['style']],
          ['font', ['bold', 'underline', 'clear']],
          ['color', ['color']],
          ['para', ['ul', 'ol', 'paragraph']],
          ['table', ['table']],
          ['insert', ['link', 'picture', 'video']],
          ['view', ['fullscreen', 'codeview', 'help']]
        ],
     
      });
      
    </script>  
<?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin_edit_SingleCourse.blade.php ENDPATH**/ ?>