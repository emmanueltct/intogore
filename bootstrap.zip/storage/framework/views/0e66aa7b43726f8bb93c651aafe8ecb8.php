<?php echo $__env->make('header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main" >
    <section class="single-post-content" >
      <div class="container" >
      <div class="row">
        <div class="col-md-8 post-content" data-aos="fade-up">
          <?php if(count($post)>0): ?>
           <img src="../../images/<?php echo e($post[0]->postthumbnail); ?>" alt="" class="img-fluid">
            <!-- ======= Single Post Content ======= -->
            <div class="single-post" >
              <div class="post-meta" style="padding:3%" >
                <span class="date"><?php echo e($post[0]->cat); ?></span> <span class="mx-1">&bullet;</span> <span><?php echo e($post[0]->createdat); ?></span>
                <span class="float-end">
                  <span class="date"></span>
                </span>
              </div>
              <h3 class="mb-5" style="margin-bottom:0px"><?php echo e($post[0]->posttitle); ?></h3>
                <button id="like-btn"  value="<?php echo e($post[0]->posts_id); ?>" class="btn btn-sm btn-outline-success "><?php if($countLike >0): ?><?php echo e($countLike); ?> <?php else: ?> 0 <?php endif; ?>  Like</button>
                <span class="mx-1">&bullet;</span> <span><a href="#scroll-to-comment" class="btn btn-sm btn-outline-success "> Comments (<?php if($Totalcomment >0): ?><?php echo e($Totalcomment); ?> <?php else: ?> 0 <?php endif; ?>)</a>
              <p style="margin-top:3px"><?php echo $post[0]->postdescription; ?></p>
            </div> 
          </div>
            <!-- End Single Post Content -->
        <div class="col-md-4">
            <!-- ======= Sidebar ======= -->
            <div class="aside-block">
              <h3 class="aside-title">Recommended Video</h3>
              <div class="video-post">
                <?php echo e($recommendVideo[0]->VideoTitle); ?>

                <a href="<?php echo e($recommendVideo[0]->sourceLink); ?>" target="_blank" title="<?php echo e($recommendVideo[0]->VideoTitle); ?>" class="link-video">
                  <embed src="<?php echo e($recommendVideo[0]->sourceLink); ?>" alt="" class="img-fluid"> </embed>
                </a>
              </div>
            </div><!-- End Video -->

            <div class="aside-block">
              <h3 class="aside-title">View Posts by Categories</h3>
              <ul class="aside-links list-unstyled">
                <li><a href="<?php echo e(route('allPost','All')); ?>"><i class="bi bi-chevron-right"></i>All</a></li>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('allPost',$cat->categoryEndLink)); ?>"><i class="bi bi-chevron-right"></i><?php echo e($cat->category); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div><!-- End Categories -->
          </div>
      </div>

      <div class="row">
      <p><?php echo $post[0]->postDetailDescription; ?></p>
            <!-- ======= Comments ======= -->
          <div class="col-sm-6 p-4">
            <div class="comments" id="scroll-to-comment">
              <h5 class="comment-title py-4"> <?php echo e($Totalcomment); ?> Comments</h5>
              <?php if(count($comments)>0): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comment d-flex mb-4">
                  <div class="flex-shrink-0">
                    <div class="avatar avatar-sm rounded-circle">
                      <img class="avatar-img" src="../../assets/img/user_icon.jpg" alt="" class="img-fluid">
                    </div>
                  </div>
                  <div class="flex-grow-1 ms-2 ms-sm-3">
                    <div class="comment-meta d-flex align-items-baseline">
                      <h6 class="me-2"><?php echo e($comment->commentatorName); ?></h6>
                      <span class="text-muted"><?php echo e($comment->created_at); ?></span>
                    </div>
                    <div class="comment-body">
                    <?php echo e($comment->postComments); ?>

                  </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
          </div>
            <!-- End Comments -->

            <!-- ======= Comments Form ======= --> 
          <div class="col-sm-6">
            <div class="row justify-content-center mt-5 p-4">

              <div class="col-lg-12">
                <h5 class="comment-title">Leave a Comment</h5>
                  <form action="" method="POST" id="commentForm">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                    <div class="col-lg-12 mb-3">
                        <input type="hidden" class="form-control" name="post_id" value="<?php echo e($post[0]->posts_id); ?>" readonly>
                      </div>
                      <div class="col-lg-6 mb-3">
                        <label for="comment-name">Name</label>
                        <input type="text" class="form-control" name="comment_name" placeholder="Enter your name">
                      </div>
                      <div class="col-lg-6 mb-3">
                        <label for="comment-email">Email</label>
                        <input type="text" class="form-control" name="comment_email" placeholder="Enter your email">
                      </div>
                      <div class="col-12 mb-3">
                        <label for="comment-message">Message</label>
                        <textarea class="form-control" name="comment_message" placeholder="Enter your name" cols="30" rows="5"></textarea>
                      </div>
                      <div class="col-12">
                        <button  class="btn btn-primary"  id="btn-submit">Post comment</button>
                      </div>
                    </div>
                  </form>
              </div>
            </div>
          </div>  
            <!-- End Comments Form -->
            <?php else: ?>
            <div class="single-post" >
              <h1 >Oops!!</h1>
              <h3>The post you are trying to read is not found! <br> <i style="color:red">Use our navigation links to for different posts on this platform</i> </h3>
              <br><br>
            </div>
            <?php endif; ?>
          </div>
         
        </div>
      </div>
    </section>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Vendor JS Files -->
  <script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../../assets/vendor/aos/aos.js"></script>
  <script src="../../assets/vendor/php-email-form/validate.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <!-- Template Main JS File -->
  <script src="../../assets/js/main.js"></script>

  <script type="text/javascript">
   $(document).ready(function(){
    
    $("#btn-submit").click(function(e){
  
        e.preventDefault();
        
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        //var post_id = $("input[id=comment_id]").val();
       // var commentatorName = $("input[id=comment_name]").val();
       // var commentatorEmail = $("input[id=comment_email]").val();
       // var message = $("input[id=comment_message]").val();
   
        $.ajax({
           type:'POST',
           url:"<?php echo e(route('sendComments')); ?>",
           data: $('#commentForm').serialize(),
           //data:{post_id:post_id,commentatorName:commentatorName ,commentatorEmail:commentatorEmail,message:message},
           success:function(data){
              alert(data.success);
              location.reload(true);
           }
        });
  
    });

    $("#like-btn").click(function(){
      var likeValue = $("#like-btn").val();
      //alert(likeValue);
      $.ajax({
           type:'GET',
           url:"<?php echo e(route('postLike')); ?>",
           data:{userLike:likeValue},
           //data:{post_id:post_id,commentatorName:commentatorName ,commentatorEmail:commentatorEmail,message:message},
           success:function(data){
            $("#like-btn").prop('disabled', true);
              //alert(data.success);
              //location.reload(true);
              $("#like-btn").text(data.result +" Like");
           }
        });

      //alert('like btn clicked');
    })
  }); 
</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\intogore\resources\views/single-post.blade.php ENDPATH**/ ?>