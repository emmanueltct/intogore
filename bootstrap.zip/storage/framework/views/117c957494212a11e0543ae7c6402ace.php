<?php echo $__env->make('titles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <a href="<?php echo e(route('ProductForm')); ?>"class="btn btn-outline-primary btn-sm float-start" ><i class="bi bi-plus"></i> Add New</a>
          <br/><br/>
          <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h1>Oops!!</h1>
                <?php echo e(implode(' ', $errors->all(':message'))); ?>

                
                </div>
             <?php endif; ?>

          <?php if(count($products)>0): ?>
            <table class="table" style="color:#2A2726">
                <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Thumbnail</th>
                    <th scope="col">Product</th>
                    <th scope="col">Price</th>
                    <th scope="col">Discount</th>
                    <th scope="col">Status</th>
                    <th scope="col">Like</th>
                    <th scope="col">Admin actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $a=0;?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $a++;?>
                <tr>
                  
                    <?php
                       // $like = App\Models\course::find($c->id)->subcourses()->count('id');
                       
                       // $comments=App\Models\course::find($c->id)->subcourses()->where('coursePublishment','Pending')->count('id');
                        //$enrolled = App\Models\course::find($c->id)->course_enrollments()->count('id');
                        //$unproved_comments=App\Models\course::find($c->id)->course_enrollments()->where('coursePayment','Not Paid')->count('id');
                        //foreach ($comments as $comment) {}
                      
                      ?>
      
                    <th><?php echo e($a); ?></th> 
                    <td><a href="<?php echo e(asset('product/images/'.$p->productThumbnail)); ?>" target="_blank"><img width="100px" src="<?php echo e(asset('product/images/'.$p->productThumbnail)); ?>"/></a></td>
                    <td><?php echo e($p->productName); ?></td>
                    <td><?php echo e($p->productPrice); ?></td>
                    <td><?php echo e($p->productDiscount); ?></td>
                    <td><?php echo e($p->Approval); ?></td>
                    <td>Total like(<?php echo e(0); ?>)</td>
                    <td>
                    <div style="display:flex;flex-direction:row; justify-content: space-around;" >
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('AdminEditProducts',$p->id)); ?>" title="Edit product information" >Edit</a>
                      
                      <form action="<?php echo e(route('AdminPublishProducts',$p->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($p->id); ?>">
                         <button type="submit" class="btn btn-success btn-sm" href="<?php echo e(route('allSubCourse',['Chapter'=>$p->id])); ?>" title="Publish Product">Publish</button> 
                       </form>

                       <form action="<?php echo e(route('deleteProduct',$p->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($p->id); ?>">
                         <button type="submit" class="btn btn-danger btn-sm" title="Delete Product">Delete</button> 
                       </form>
                      </div>
                    </td>
                  </tr> 
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            <?php else: ?>
            <div class="col-sm-12 single-post" >
              <h1 >Oops!!</h1>
              <h3><span>It seem s like no person enrolled to any course</span> <br>
              <i style="color:red">Please keep refreshing for any update</i> </h3>
            </div> 
          <?php endif; ?>
          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-All-Products.blade.php ENDPATH**/ ?>