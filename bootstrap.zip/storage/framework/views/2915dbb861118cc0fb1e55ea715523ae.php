<?php echo $__env->make('admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main id="main">
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h3 class="page-title" style="font-size:24px">Describe your Post here</h3>
          </div>
        <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
         <?php endif; ?>
        </div>
          <form method="post"  action="<?php echo e(route('SaveRecommendVideo')); ?>"  class="php-email-form" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
            <div class="form-group">
             <label>add recommend title</label> 
                <input type="text" name="VideoTitle" class="form-control" id="trendingTitle" placeholder="give your post heading of on trending news " required>
            </div>
            <div class="form-group">
              <input type="url" class="form-control" name="sourceLink" id="trendingLink" required>
              <label>paste source link for your post you want to share</label>
            </div>
            <div class="my-3">
              <div class="loading">Loading</div>
              <div class="error-message"></div>
              <div class="sent-message">Your message has been sent. Thank you!</div>
            </div>
            <div class="text-center"><input type="submit" value="Send Post"></div>
          </form>
        </div><!-- End Contact Form -->
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/Admin-recommend-video.blade.php ENDPATH**/ ?>