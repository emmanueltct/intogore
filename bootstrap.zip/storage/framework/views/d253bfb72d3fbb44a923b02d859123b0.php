<?php echo $__env->make('titles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main id="main">       
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h3 class="page-title" style="font-size:24px">Describe your Post here</h3>
          </div>
        <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
         <?php endif; ?>
           <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <h1>Oops!!</h1>
                   <h3> <?php echo e(implode(' ', $errors->all(':message'))); ?></h3>
                   <br/>
                  </div>
             <?php endif; ?>
        </div>
        <div class="row">
        <div class="col-lg-12 d-flex justify-content-center" >
          <form method="post"  action="<?php echo e(route('postProductForm')); ?>"  class="php-email-form " enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="companyTitle" class="form-control" id="companyTitle" Value="INTOGORE FITECH CRYPTO PRODUCTS" readonly>
                <label>Default Title  you can't change it</label>
            </div>
            <div class="form-group">
                <input type="text" name="productName" class="form-control" id="productName" value="<?php echo e(old('productName')); ?>"  placeholder="Product name Ex:Red Hat" >
                <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            <div class="form-group">
                <input type="number" name="productPrice" class="form-control" id="productPrice" value="<?php echo e(old('productPrice')); ?>" placeholder="Product price"  >
                <?php $__errorArgs = ['productPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input type="number" name="productDiscount" class="form-control" id="productDiscount" value="0" >
                <label>Don't change anything if no discount leave default value</label>
                <?php $__errorArgs = ['productDiscount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input type="text" name="Currency" class="form-control" id="priceCurrency" value="<?php echo e(old('Currency')); ?>"  placeholder="Ex:Rwf or USDT">
                <label>unit Currency</label>
                <?php $__errorArgs = ['Currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <input type="file" class="form-control" name="productThumbnail" id="productThumbnail">
              <label>Product Thumbnail visible to web page</label>
              <?php $__errorArgs = ['productThumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="text-center"><input type="submit" value="Send Post" class="btn btn-primary"></div>
          </form>
        </div><!-- End Contact Form -->
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intogore\resources\views/products.blade.php ENDPATH**/ ?>