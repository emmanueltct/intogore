<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('trendings', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('trendingTitle')->unique();
            $table->string('urlEndPart')->unique();
            $table->text('sourceLink');
            $table->text('Comments');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('trendings');
    }
};
