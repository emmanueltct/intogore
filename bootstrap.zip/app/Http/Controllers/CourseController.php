<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\Models\course;
use Illuminate\Http\Request;
use DB;
class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('add-course');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $title= str_replace(' ', '-', strtolower($request->courseTitle));
        $id= Str::orderedUuid();
       course::create(['id'=>$id,'courseTitle'=>$request->courseTitle,'courseEndLink'=>$title,'courseDescription'=>$request->mainCourseIntro]);
       return redirect('/admin/Add-SubCourse')->with('success', 'Main Course topic was saved successfully! please add sub courses categories');
    

    }
 
    public function AllCourseList(){
        $course=course::all();
        return view('Admin-View-All-Course',compact('course'));
    }


    /**
     * Display the specified resource.
     */
    public function show(course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($course)
    {
        //
        
        $singlecourse=DB::table('courses')->select()
        ->where('courses.id','=',$course)
        ->first();
        return view('Admin_edit-course',compact(['singlecourse']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,  $id)
    {
        //
       // return $request->all();
        $title= str_replace(' ', '-', strtolower($request->courseTitle));
        course::where('id',$id)->
        update(['courseTitle'=>$request->courseTitle,
        'courseEndLink'=>$title,
        'courseDescription'=>$request->mainCourseIntro,
        'CourseEnroll' =>$request->subscription,
        'CoursePrice' =>$request->courseprice]);
        return redirect()->route('AdmincourseList')->withSuccess('Course information is updated'); 

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, $course)
    {
        //
         
        $affected = DB::table('courses') ->where('id', $course)->Delete();
        return redirect()->route('AdmincourseList')->withErrors(['user_update'=>'The course is deleted to our list']);
    }
}
